#pragma once

// Dumped with Dumper-7!

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

#include "../SDK.hpp"

namespace SDK
{
namespace Params
{
//---------------------------------------------------------------------------------------------------------------------
// PARAMETERS
//---------------------------------------------------------------------------------------------------------------------

// 0x28 (0x28 - 0x0)
// Function ActivityBrowserTag.ActivityBrowserTag_C.HandleStyling
struct UActivityBrowserTag_C_HandleStyling_Params
{
public:
	struct FSlateColor                           K2Node_MakeStruct_SlateColor;                      // 0x0(0x28)()
};

// 0x1 (0x1 - 0x0)
// Function ActivityBrowserTag.ActivityBrowserTag_C.PreConstruct
struct UActivityBrowserTag_C_PreConstruct_Params
{
public:
	bool                                         IsDesignTime;                                      // 0x0(0x1)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
};

// 0x0 (0x0 - 0x0)
// Function ActivityBrowserTag.ActivityBrowserTag_C.Construct
struct UActivityBrowserTag_C_Construct_Params
{
public:
};

// 0x5 (0x5 - 0x0)
// Function ActivityBrowserTag.ActivityBrowserTag_C.ExecuteUbergraph_ActivityBrowserTag
struct UActivityBrowserTag_C_ExecuteUbergraph_ActivityBrowserTag_Params
{
public:
	int32                                        EntryPoint;                                        // 0x0(0x4)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         K2Node_Event_IsDesignTime;                         // 0x4(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor)
};

}
}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
